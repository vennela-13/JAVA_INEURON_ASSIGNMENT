
public class Pangram {

	public static void main(String[] args) {

		String s1 = new String("Abcd");
		String s2 = s1.toLowerCase();
		//System.out.println(s2);
		boolean c = true;
		for (char ch = 'a'; ch <= 'z'; ch++) {
			if (!s2.contains(s2.valueOf(ch))) {
				c = false;
				break;
			}
		}

		if(c)

			System.out.println("Pangram String");
		else

			System.out.println("Not a Pangram String");
	}

}
