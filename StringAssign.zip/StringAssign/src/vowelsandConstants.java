
public class vowelsandConstants {

	public static void main(String[] args) {
		
		String s1=new String("veNNelA");
		s1=s1.toLowerCase();
		String s2=" ";
		String s3=" ";
		for(int i=0;i<=s1.length()-1;i++) {
			
			if(s1.charAt(i)=='a' || s1.charAt(i)=='e' || s1.charAt(i)=='i' || s1.charAt(i)=='o' || s1.charAt(i)=='u') {
				s2=s2+s1.charAt(i);
			}
			else
				s3=s3+s1.charAt(i);
		}
		System.out.println("Vowels:" + " "+s2);
		System.out.println("Constants:" + " "+s3);

	}

}
