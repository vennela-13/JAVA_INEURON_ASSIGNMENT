
public class Anagram {

	public static void main(String[] args) {
		 String s1=new String("listen");
		 String s2=new String("silent");
		 int c=0;
         for(int i=0;i<=s1.length()-1;i++) {
        	 for(int j=0;j<=s2.length()-1;j++) {
        		 if(i==j)
        		 {
        			 //System.out.println(i+""+"anagram");
        			 c++;
        		 }
        	 }
         }
         if(s1.length()==c&& s2.length()==c)
         {
        	 System.out.println("Anagram");
         }
         else 
        	 System.out.println("Not a Anagram");
	}

}
