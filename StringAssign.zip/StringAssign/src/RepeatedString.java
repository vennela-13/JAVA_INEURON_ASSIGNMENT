
public class RepeatedString {

	public static void main(String[] args) {
		String s1=new String("abcdaddddaa");
		int c=0;
		char string[] = s1.toCharArray();  
		for(int i=0;i<=string.length-1;i++) {
			c=1;
			for(int j=i+1;j<=string.length-1;j++) {
				if(string[i]==string[j]) {
					c++;
					 string[j] = '0';  
				}
				//j=0;
			}
			//System.out.println(c);
			 if(c > 1 && string[i] != '0') { 
		           
			    System.out.println(string[i]);
			 }
			 //System.out.println(string[i]);
		}
		
		 

	}

}
