
public class Stringreverse {

	public static void main(String[] args) {
		
		String s= new String("iNeuron");
		String S2="";
		for(int i=s.length()-1;i>=0;i--)
		{
			S2=S2+s.charAt(i);
			
		}
		System.out.println(S2);
		
	}

}
