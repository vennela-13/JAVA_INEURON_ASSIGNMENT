
public class Specialcharcount {

	public static void main(String[] args) {
		String s1=new String("Ve@nn^$#el$");
		int c = 0,c1 = 0,c2 = 0,c3 = 0;
		for(int i=0;i<=s1.length()-1;i++) {
			 if (s1.charAt(i) >= 'A' && s1.charAt(i)<= 'Z') {
				 c++;
			 }
		        else if (s1.charAt(i) >= 'a' && s1.charAt(i) <= 'z') {
		        	c1++;
		        }
		        else if (s1.charAt(i)>= '0' && s1.charAt(i)<= '9') {
		        	c2++;
		        }

		        else
		          c3++;
		}
		System.out.println("Number of special characters:" + " "+c3);
	}

}
