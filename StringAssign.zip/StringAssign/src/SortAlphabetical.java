import java.util.Arrays;

public class SortAlphabetical {

	public static void main(String[] args) {
		
		String s1=new String("ghtsedcba");

		char[] ar = s1.toCharArray();
		//System.out.println(ar);
		
		Arrays.sort(ar);
		String sorted = String.valueOf(ar);
		System.out.println(sorted);
	}

}
