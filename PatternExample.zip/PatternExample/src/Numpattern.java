
public class Numpattern {

	public static void main(String[] args) {

		int i, j;
		int n = 4;
		for (i = 1; i <= n; i++) {

			for (j = 1; j <= n; j++) {
				System.out.print(i);

			}
			System.out.println();
		}

	}

}
