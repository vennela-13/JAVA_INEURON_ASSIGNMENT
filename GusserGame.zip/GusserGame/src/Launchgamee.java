
import java.util.Scanner;

class Guesser {
	int guessNum;
	Umpire u = new Umpire();
	Scanner scan = new Scanner(System.in);
	public int guessNumber() {
		
		System.out.println("Guesser kindly guess the number in between 1 to 10");
		guessNum = scan.nextInt();
		System.out.println("G0"+ guessNum);
		return guessNum;

	}
	public int check() {
		int res=guessNum;
		if(res > 10 || res < 0)
		{ 
			System.out.println("You have guessed the number:" + " " + res +" " + "Kindly guess the number again:");
			res=guessNumber();
			System.out.println("G1"+ res);
			check();
			System.out.println("G2"+ res);
			u.collectNumFromPlayer();
			System.out.println("G3"+ res);
		}
		else { 
			System.out.println("G4"+ res);
			u.collectNumFromPlayer();
			System.out.println("G5"+ res);
		}
		return res;


	}

}

class Player {
	 int pguessNum;
	Umpire u = new Umpire();
	Scanner scan = new Scanner(System.in);
	public int guessNumber() {		
		System.out.println("Player kindly guess the number in between 1 to 10");
		pguessNum = scan.nextInt();	
		System.out.println("P0"+ pguessNum);
		//check();
		return pguessNum;
	}
	public int check() {
		int res=pguessNum;
		  if (pguessNum > 10 || pguessNum < 0) {
			  System.out.println("You have guessed the number:" + " " + pguessNum +" " + "Kindly guess the number again:");
			  System.out.println("P1"+ pguessNum);
		     res=guessNumber();
		     System.out.println("P2"+ pguessNum);
		     check(); 
		     System.out.println("P3"+ pguessNum);
		  }
		return res;

		}
}

class Umpire {
    int numFromGuesser;
	int numFromPlayer1;
	int numFromPlayer2;
	int numFromPlayer3;

	public void collectNumFromGuesser() {
		Guesser g = new Guesser();
		System.out.println("numFromGuesser"+ numFromGuesser);
		g.guessNumber();
		numFromGuesser = g.check();	
		System.out.println("numFromGuesser1"+ numFromGuesser);

	}

	public void collectNumFromPlayer() {
		Player p1 = new Player();
		Player p2 = new Player();
		Player p3 = new Player();

		p1.guessNumber();
		numFromPlayer1 = p1.check();
		System.out.println("BnumFromPlayer1 "+ numFromPlayer1);
		//p1.check();
		System.out.println("AnumFromPlayer1 "+ numFromPlayer1);
		p2.guessNumber();
		numFromPlayer2 = p2.check();
		System.out.println("BnumFromPlayer2 "+ numFromPlayer2);
		//p2.check();
		p2.guessNumber();
		System.out.println("AnumFromPlayer2 "+ numFromPlayer2);
		numFromPlayer3 = p3.check();
		System.out.println("BnumFromPlayer3 "+ numFromPlayer3);
		//p3.check();
		System.out.println("AnumFromPlayer3 "+ numFromPlayer3);
		compare();
	}
	public void compare() {

		if (numFromGuesser == numFromPlayer1) {
			if (numFromGuesser == numFromPlayer2 && numFromGuesser == numFromPlayer3) {
				System.out.println("Game tied all three players guessed correctly");
			} else if (numFromGuesser == numFromPlayer2) {
				System.out.println("Player 1 and Player2 won the game");
			} else if (numFromGuesser == numFromPlayer3) {
				System.out.println("Player 1 and Player3 won ");
			} else {

				System.out.println("Player 1 won the game");
			}
		}

		else if (numFromGuesser == numFromPlayer2) {

			if (numFromGuesser == numFromPlayer3) {
				System.out.println("Player 2 and Player3 won the game");
			} else {
				System.out.println("Player 2 won the game");
			}
		}

		else if (numFromGuesser == numFromPlayer3) {
			System.out.println("Player 3 won the game");
		} else {
			System.out.println("Game lost! try again");
		}
	}

}

public class Launchgamee {

	public static void main(String[] args) {

		Umpire u = new Umpire();
		u.collectNumFromGuesser();
		// u.collectNumFromPlayer();
		//u.compare();
		

	}

}
