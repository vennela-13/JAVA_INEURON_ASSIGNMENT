import java.util.Arrays;
import java.util.Scanner;

class GuesserNum {
	int guessNumber;
	gameEnd ge = new gameEnd();
	UmpNumber um = new UmpNumber();
	int count = 0;

	public void calc() {

		if (guessNumber > 10 || guessNumber < 0) {

			System.out.println(
					"You have guessed the number:" + " " + guessNumber + " " + "Kindly guess the number again:");
			check();

		}

	}

	public int check() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Guesser kindly guess the number in between 1 to 10");
		guessNumber = scan.nextInt();
		count++;

		if (count >= 3) {
			System.out.println("You have exceeded " + count + " " + "limits" + " " + " Play Again!...");
			ge.gameEnds();
		} else {
			calc();
			if (count < 3) {
				um.collectplayerNum();
			}

		}

		return guessNumber;

	}
}

class PlayerNum {

	int PlayerNumber;
	gameEnd ge = new gameEnd();
	UmpNumber um = new UmpNumber();
	int count = 0;

	public void calc() {
		if (PlayerNumber > 10 || PlayerNumber < 0) {
			System.out.println(
					"You have guessed the number:" + " " + PlayerNumber + " " + "Kindly guess the number again: ");
			check1();
		}
	}

	public int check1() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Player kindly guess the number in between 1 to 10");
		PlayerNumber = scan.nextInt();

		calc();

		return PlayerNumber;

	}

}

class UmpNumber {

	int gNum;
	int[] pnum = new int[5];
	int n = 5;

	void collectguessNum() {
		GuesserNum gn = new GuesserNum();
		gNum = gn.check();
	}

	void collectplayerNum() {
		PlayerNum pn = new PlayerNum();
		for (int i = 0; i < n; i++) {
			pnum[i] = pn.check1();
		}
	}

	void compare() {
		int i = 0;

		for (i = 0; i < pnum.length; i++) {

			if (gNum == pnum[i]) {
				System.out.println("Player" + " " + (i + 1) + " " + "won the game");

			}

		}

	}

}

class gameStart {
	int end;

	void gameStarts() {
		System.out.println("Game Rules!...");
		System.out.println("one Guesser,5 Players." + "\n\n" + "Guesser has limit of 3 to enter the correct number");
		System.out.println("Players who guess the same number wins the game!...");
		System.out.println("Press 0 to EXIT the game or Press  any Key to CONTIUNE ...");
		Scanner scan = new Scanner(System.in);
		end = scan.nextInt();
		if (end == 0) {

			System.out.println("Thanks!...");

		} else {
			UmpNumber um = new UmpNumber();
			um.collectguessNum();
		}
	}
}

class gameEnd {
	void gameEnds() {
		System.out.println("Thanks!...");
	}
}

public class Guessgamer {

	public static void main(String[] args) {
		gameStart g = new gameStart();
		g.gameStarts();

	}

}
